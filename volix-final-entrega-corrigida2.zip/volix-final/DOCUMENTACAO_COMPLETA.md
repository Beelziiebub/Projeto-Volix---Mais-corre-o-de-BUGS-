# Documentação técnica — Volix

## 1. Objetivo
Aplicação local de monitoramento de produtos públicos da Shopee Brasil, com coleta, persistência, enriquecimento e histórico de preços.

## 2. Arquitetura
`Frontend estático → Express API → Scraper/Parser → Repository → SQLite`.

O scheduler chama o mesmo serviço de coleta em intervalos configuráveis.

## 3. Fluxo de cadastro
1. Operador cola uma URL canônica ou pesquisa um termo.
2. API valida a origem/formato da URL.
3. Scraper faz requisição com timeout.
4. Em falha transitória, aplica retry e backoff exponencial.
5. Parser extrai nome, descrição, IDs, preços, atributos, imagens e variações disponíveis.
6. Repository atualiza o produto.
7. Uma nova coleta de preço é inserida em `price_history` sem apagar registros anteriores.
8. Dashboard mostra último preço e histórico.

## 4. Persistência
O SQLite usa foreign keys, índices e tabelas normalizadas. O histórico é append-only no fluxo normal da aplicação.

## 5. Resiliência
- Timeout configurável.
- Quatro tentativas por padrão.
- Backoff exponencial.
- Logs de tentativa, sucesso e falha.
- Detecção de HTTP 401/403/429 e sinais comuns de desafio.
- Falha de um produto no scheduler não interrompe os demais.

## 6. Anti-bot / Akamai
A aplicação não implementa evasão de controles de acesso. Em vez disso, identifica desafios/bloqueios e retorna um erro explícito. A estratégia é compatível com o requisito do teste de documentar a abordagem e limitações. Para produção, deve-se usar uma fonte autorizada quando disponível.

## 7. Modelo de dados
`product`: identidade e estado atual.

`product_attribute`: pares chave/valor da ficha técnica.

`price_history`: `price_pix`, `price_card`, moeda e timestamp.

`product_image`: URLs e posição.

`product_variant`: SKU/nome/preços quando disponíveis.

## 8. Interface
A interface permite:
- adicionar por URL;
- pesquisar;
- adicionar resultado da pesquisa;
- recoletar;
- visualizar detalhes;
- abrir a página original;
- visualizar atributos, imagens, variações e histórico.

## 9. Observabilidade
O sistema registra cada tentativa finalizada em `collection_log`, diferenciando `success`, `blocked` e `error`, além de duração e timestamp. O dashboard mostra indicadores das últimas 24 horas e os últimos logs.

## 10. Testes
Existem testes para:
- parser de metadados e preço;
- detecção de bloqueio;
- extração de IDs/preços do payload;
- persistência e histórico no SQLite.

## 11. Dados iniciais
`backend/data/volix.sqlite` contém cinco produtos de referência e um snapshot inicial de preço para tornar a aplicação demonstrável. Uma nova coleta deve ser executada antes da entrega para atualizar os dados.

## 12. Entrega
Antes de enviar:
1. instalar dependências;
2. executar `npm test`;
3. executar `npm run seed`;
4. executar `npm start`;
5. abrir o dashboard;
6. testar cadastro, busca, coleta, detalhes e histórico;
7. confirmar novamente os cinco links da Shopee.

## 13. Melhorias futuras
Worker/fila distribuída, métricas, cache, testes de integração HTTP, gráficos de histórico, preços por SKU mais completos, imagem Docker própria e integração autorizada para coleta.

## Recursos de operação adicionados na versão final

### Filtros, ordenação e paginação
A listagem permite pesquisar por nome/marca/vendedor, filtrar por categoria e pelo último status de coleta, ordenar por preço ou nome e paginar os resultados. Isso prepara a interface para uma lista maior sem alterar o modelo do MVP.

### Comparação
A interface permite selecionar produtos monitorados e comparar preço PIX, preço no cartão, avaliação e vendedor. A comparação usa somente dados já persistidos no SQLite.

### Exportação
`GET /api/export.csv` exporta a visão filtrada dos produtos em CSV UTF-8 com BOM, facilitando análise externa sem criar uma funcionalidade fora do escopo.

### Fila e cache
As coletas são colocadas em uma fila em memória e executadas de forma serial. Um cache curto por URL evita duplicações imediatas. A intenção é demonstrar throttling operacional e reduzir carga sobre a fonte pública, não contornar controles anti-bot.

### Health check
`GET /api/health` valida o SQLite e informa fila, execução e uptime.

### Limite deliberado de escopo
Não foram adicionados autenticação, pagamentos, carrinho, vendas ou outros módulos de e-commerce porque não contribuem diretamente para o objetivo do teste: monitorar dados públicos de produtos, enriquecer o banco e operar coletas.
