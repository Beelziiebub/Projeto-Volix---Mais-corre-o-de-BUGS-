import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cron from 'node-cron';
import './db.js';
import db from './db.js';
import { upsertProduct, createPendingProduct, replaceAttributes, addPrices, addImages, replaceVariants, listProducts, getProduct, addCollectionLog, listCollectionLogs, getStats, getCategories, getProductsByIds } from './repository.js';
import { scrapeShopee, searchShopee } from './scraper.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.resolve(__dirname,'../../frontend')));
const isShopeeUrl=v=>/^https?:\/\/(?:www\.)?shopee\.com\.br\/.+?-i\.\d+\.\d+(?:[/?#].*)?$/i.test(String(v||''));
const validId=v=>Number.isInteger(Number(v))&&Number(v)>0;

const queue=[]; let running=false;
const cache=new Map(); const CACHE_TTL=Number(process.env.SCRAPE_CACHE_TTL_MS||60000);
function enqueue(task){ return new Promise((resolve,reject)=>{queue.push({task,resolve,reject});processQueue();}); }
async function processQueue(){ if(running)return; running=true; while(queue.length){const item=queue.shift();try{item.resolve(await item.task());}catch(e){item.reject(e);}} running=false; }

app.get('/api/health',(_,res)=>{try{db.prepare('SELECT 1 AS ok').get();res.json({ok:true,database:'connected',queue:queue.length,running,uptime:Math.round(process.uptime()),time:new Date().toISOString()});}catch(e){res.status(503).json({ok:false,database:'error',detail:e.message});}});
app.get('/api/stats',(_,res)=>res.json({...getStats(),queue_size:queue.length,queue_running:running}));
app.get('/api/logs',(req,res)=>res.json(listCollectionLogs(req.query.limit)));
app.get('/api/categories',(_,res)=>res.json(getCategories()));
app.get('/api/products',(req,res)=>res.json(listProducts({q:String(req.query.q||'').trim(),category:String(req.query.category||'').trim(),status:String(req.query.status||'').trim(),sort:String(req.query.sort||'updated'),page:req.query.page,pageSize:req.query.pageSize})));
app.get('/api/products/:id',(req,res)=>{if(!validId(req.params.id))return res.status(400).json({error:'ID inválido'});const p=getProduct(Number(req.params.id));if(!p)return res.status(404).json({error:'Produto não encontrado'});res.json(p);});
app.get('/api/compare',(req,res)=>{const ids=String(req.query.ids||'').split(',').map(Number).filter(Number.isInteger).slice(0,5);if(ids.length<2)return res.status(400).json({error:'Informe pelo menos 2 IDs em ids=1,2'});res.json(getProductsByIds(ids));});
app.get('/api/export.csv',(req,res)=>{const result=listProducts({q:String(req.query.q||''),category:String(req.query.category||''),status:String(req.query.status||''),sort:'name',page:1,pageSize:10000});const esc=v=>`"${String(v??'').replaceAll('"','""')}"`;const rows=[['id','name','brand','seller','price_pix','price_card','rating','rating_count','last_status','collected_at','url'],...result.items.map(p=>[p.id,p.name,p.brand,p.seller,p.price_pix,p.price_card,p.rating,p.rating_count,p.last_status,p.collected_at,p.url])];res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="volix-products.csv"');res.send('\ufeff'+rows.map(r=>r.map(esc).join(';')).join('\n'));});
app.get('/api/search',async(req,res)=>{
  try{
    const q=String(req.query.q||'').trim();
    if(q.length<2)return res.status(400).json({error:'Informe uma busca com pelo menos 2 caracteres.'});
    try {
      const results=await searchShopee(q);
      res.json({results,source:'shopee'});
    } catch(e) {
      if(e.message!=='ANTI_BOT_CHALLENGE') throw e;
      const local=listProducts({q,sort:'random',page:1,pageSize:20}).items;
      res.json({
        results:local.map(p=>({title:p.name,url:p.url,local:true})),
        source:'local-fallback',
        message:'A Shopee bloqueou a busca automática. Exibindo produtos já monitorados como alternativa.'
      });
    }
  }catch(e){res.status(502).json({error:'Falha na busca',detail:e.message});}
});

async function collect(url, productId=null) {
  const cached=cache.get(url); if(cached && Date.now()-cached.at<CACHE_TTL) return cached.data;
  const started=Date.now();
  try {
    const data=await scrapeShopee(url);
    const id=upsertProduct(data); replaceAttributes(id,data.attributes); addImages(id,data.images); replaceVariants(id,data.variants); addPrices(id,data.price_pix,data.price_card);
    const result=getProduct(id); cache.set(url,{at:Date.now(),data:result});
    addCollectionLog({product_id:id,status:'success',message:'Coleta concluída com sucesso',duration_ms:Date.now()-started});
    return result;
  } catch (e) {
    const status=e.message==='ANTI_BOT_CHALLENGE'?'blocked':'error';
    addCollectionLog({product_id:productId,status,message:e.message,duration_ms:Date.now()-started});
    throw e;
  }
}
async function queuedCollect(url,id=null){return enqueue(()=>collect(url,id));}
app.post('/api/products',async(req,res)=>{
  try{
    const url=String(req.body?.url||'').trim();
    if(!isShopeeUrl(url))return res.status(400).json({error:'Informe uma URL canônica de produto da Shopee Brasil.'});
    res.status(201).json(await queuedCollect(url));
  }catch(e){
    if(e.message==='ANTI_BOT_CHALLENGE'){
      const match=String(req.body?.url||'').match(/-i\.(\d+)\.(\d+)/i);
      const id=createPendingProduct({url:String(req.body?.url||'').trim(),shopee_shop_id:match?.[1]??null,shopee_item_id:match?.[2]??null});
      addCollectionLog({product_id:id,status:'blocked',message:'A Shopee respondeu com um desafio anti-bot. Produto salvo como pendente para nova tentativa.',duration_ms:null});
      return res.status(201).json({...getProduct(id),blocked:true,message:'Produto salvo, mas a coleta foi bloqueada pelo anti-bot da Shopee.'});
    }
    res.status(502).json({error:'Falha na coleta',detail:e.message});
  }
});
app.post('/api/products/:id/collect',async(req,res)=>{
  try{
    if(!validId(req.params.id))return res.status(400).json({error:'ID inválido'});
    const p=getProduct(Number(req.params.id));
    if(!p)return res.status(404).json({error:'Produto não encontrado'});
    res.json(await queuedCollect(p.url,p.id));
  }catch(e){
    if(e.message==='ANTI_BOT_CHALLENGE'){
      const product=getProduct(Number(req.params.id));
      return res.status(200).json({...product,blocked:true,message:'Nova tentativa bloqueada pelo anti-bot da Shopee. O produto continua monitorado.'});
    }
    res.status(502).json({error:'Falha na coleta',detail:e.message});
  }
});

const interval=process.env.COLLECTION_CRON||'0 */6 * * *';
const job=cron.schedule(interval,async()=>{for(const p of listProducts({page:1,pageSize:10000}).items){try{await queuedCollect(p.url,p.id);console.log(`[scheduler] coleta concluída id=${p.id}`);}catch(e){console.warn(`[scheduler] falha id=${p.id} erro=${e.message}`);}}});
const port=Number(process.env.PORT||3000);
const server=app.listen(port,()=>console.log(`Volix rodando em http://localhost:${port}`));
const shutdown=()=>{job.stop();server.close(()=>process.exit(0));};
process.on('SIGINT',shutdown); process.on('SIGTERM',shutdown);
export { app, enqueue, processQueue };
