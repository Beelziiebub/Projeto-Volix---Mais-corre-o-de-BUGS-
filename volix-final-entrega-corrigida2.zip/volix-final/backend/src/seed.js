import db from './db.js';
import {upsertProduct,replaceAttributes,addPrices,addImages,replaceVariants} from './repository.js';

const products=[
 {name:'Smartwatch Relógio Inteligente Haiz My Watch I Fit',url:'https://shopee.com.br/Smartwatch-Rel%C3%B3gio-Inteligente-Haiz-My-Watch-I-Fit-i.1612621589.58206596137',price_pix:133.00,price_card:139.99,attributes:{Categoria:'Eletrônicos / vestível',Variacoes:'3'},variants:[{name:'3 variações disponíveis'}]},
 {name:'Fritadeira Sem Óleo Air Fryer 3,5L Mondial AF-30-I 220V',url:'https://shopee.com.br/Fritadeira-Sem-%C3%93leo-Air-Fryer-3-5L-Mondial-AF-30-I-220V-i.707764315.23098739486',price_pix:323.91,price_card:359.90,attributes:{Categoria:'Casa / eletroportáteis',Marca:'Mondial'}},
 {name:'fone de ouvido bluetooth Y30 Tws resistente a água com microfone original',url:'https://shopee.com.br/fone-de-ouvido-bluetooth-Y30-Tws-resistente-a-%C3%A1gua-com-microfone-original-i.297251051.19725181060',price_pix:34.90,price_card:39.90,attributes:{Categoria:'Áudio',Modelo:'Y30 TWS'},variants:[{name:'Fone na caixa'},{name:'Fone na embalagem plástica'}]},
 {name:'Caixa De Som Bluetooth Imenso I X51 120w Ipx4 Rgb C/ 2 Mic',url:'https://shopee.com.br/Caixa-De-Som-Bluetooth-Imenso-I-X51-120w-Ipx4-Rgb-C-2-Mic-i.551459340.22598400913',price_pix:432.00,price_card:480.00,attributes:{Categoria:'Áudio',Potencia:'120W',Protecao:'IPX4'}},
 {name:'Suporte De Parede Para Controle Remoto I Organizador De Controles Remoto',url:'https://shopee.com.br/Suporte-De-Parede-Para-Controle-Remoto-I-Organizador-De-Controles-Remoto-i.330461348.22694882636',price_pix:23.74,price_card:24.99,attributes:{Categoria:'Casa',Variacoes:'2'}}
];

for(const p of products){
  const existing=db.prepare('SELECT id FROM product WHERE url=?').get(p.url);
  if(existing) continue;
  const id=upsertProduct({...p,shopee_item_id:p.url.match(/i\.\d+\.(\d+)/)?.[1]??null,shopee_shop_id:p.url.match(/i\.(\d+)\./)?.[1]??null,description:'Snapshot inicial obtido de página pública da Shopee; execute uma nova coleta para atualizar os dados.',brand:p.attributes.Marca??null,seller:null,rating:null,rating_count:null,sold_count:null});
  replaceAttributes(id,p.attributes); replaceVariants(id,p.variants||[]); addPrices(id,p.price_pix,p.price_card);
}
console.log('Seed concluído com 5 produtos reais de referência.');
db.close();
