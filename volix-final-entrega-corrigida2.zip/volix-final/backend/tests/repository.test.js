import test from 'node:test';
import assert from 'node:assert/strict';
import db from '../src/db.js';
import {upsertProduct,addPrices,listProducts,getStats,addCollectionLog} from '../src/repository.js';

test('persistência mantém produto e histórico de preços',()=>{
  const suffix=Date.now()+Math.random();
  const id=upsertProduct({shopee_item_id:`test-${suffix}`,shopee_shop_id:'1',name:'Produto teste',description:'x',url:`https://shopee.com.br/teste-i.1.${suffix}`,brand:'Teste',seller:'Loja',rating:5,rating_count:1,sold_count:2});
  addPrices(id,10,12); addPrices(id,9,11);
  const p=listProducts({q:'Produto teste',page:1,pageSize:10});
  assert.equal(p.total,1); assert.equal(p.items[0].price_pix,9);
  const count=db.prepare('SELECT COUNT(*) c FROM price_history WHERE product_id=?').get(id).c;
  assert.equal(count,2);
  addCollectionLog({product_id:id,status:'success',message:'ok',duration_ms:10});
  assert.equal(getStats().products>=1,true);
});
