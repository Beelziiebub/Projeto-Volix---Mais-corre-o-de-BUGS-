import test from 'node:test';
import assert from 'node:assert/strict';
import {parseShopeeHtml, looksBlocked} from '../src/scraper.js';

test('parser extrai metadados básicos e preço',()=>{
  const html=`<html><head>
    <meta property="og:title" content="Fone TWS">
    <meta property="og:description" content="Descrição">
    <meta property="og:image" content="https://img.test/a.jpg">
    </head><body><div class="price">R$ 59,90</div>
    <table><tr><td>Marca</td><td>Teste</td></tr></table></body></html>`;
  const p=parseShopeeHtml(html,'https://shopee.com.br/x-i.1.2');
  assert.equal(p.name,'Fone TWS'); assert.equal(p.description,'Descrição'); assert.equal(p.brand,'Teste');
  assert.equal(p.price_pix,59.9); assert.equal(p.images.length,1);
});

test('detecta sinais de bloqueio',()=>{
  assert.equal(looksBlocked('<html>Access Denied by Akamai</html>',403),true);
  assert.equal(looksBlocked('<html>produto normal</html>',200),false);
});

test('extrai ids canônicos de payload embutido',()=>{
  const html=`<script>window.__x={"shopid":123,"itemid":456,"price":5990000,"min_price":4990000};</script>`;
  const p=parseShopeeHtml(html,'https://shopee.com.br/x-i.123.456');
  assert.equal(p.shopee_shop_id,'123'); assert.equal(p.shopee_item_id,'456');
  assert.equal(p.price_card,59.9); assert.equal(p.price_pix,49.9);
});

test('normaliza payload de preço em centavos sem alterar decimal',()=>{
  const html=`<script>window.__x={"shopid":1,"itemid":2,"price":12990,"min_price":11990};</script>`;
  const p=parseShopeeHtml(html,'https://shopee.com.br/x-i.1.2');
  assert.equal(p.price_card,129.9); assert.equal(p.price_pix,119.9);
});

test('preserva preço visível em formato brasileiro',()=>{
  const html=`<div class="price">R$ 1.299,90</div>`;
  const p=parseShopeeHtml(html,'https://shopee.com.br/x-i.1.2');
  assert.equal(p.price_pix,1299.9); assert.equal(p.price_card,1299.9);
});
