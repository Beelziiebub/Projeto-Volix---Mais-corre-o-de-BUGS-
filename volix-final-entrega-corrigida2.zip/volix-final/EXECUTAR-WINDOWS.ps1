$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

Write-Host '========================================'
Write-Host '  VOLIX - Monitor de Precos Shopee'
Write-Host '========================================'

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js nao foi encontrado. Instale Node.js 20 ou superior.' }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw 'npm nao foi encontrado.' }
$major = [int](node -p "process.versions.node.split('.')[0]")
if ($major -lt 20) { throw "Node.js 20+ e obrigatorio. Versao encontrada: $(node --version)" }

Write-Host '[1/5] Instalando dependencias do backend...'
npm --prefix backend install
Write-Host '[2/5] Preparando banco SQLite...'
npm --prefix backend run seed
Write-Host '[3/5] Executando testes...'
npm --prefix backend test
Write-Host '[4/5] Verificando sintaxe JavaScript...'
Get-ChildItem backend/src/*.js,backend/tests/*.js | ForEach-Object { node --check $_.FullName }
Write-Host '[5/5] Iniciando aplicacao...'
Write-Host 'Abra http://localhost:3000 no navegador.'
npm --prefix backend start
