#!/usr/bin/env bash
# Atalho oficial para macOS.
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT_DIR/scripts/rodar-unix.sh" "$@"
