# Volix — Monitor de preços Shopee

Implementação Full-Stack para o teste técnico da Volix. A aplicação roda localmente, permite pesquisar/adicionar produtos públicos da Shopee Brasil, executar coleta, persistir dados em SQLite e manter histórico de preços.

## Stack
- Node.js 20+
- Express
- Cheerio
- SQLite via better-sqlite3
- node-cron
- Frontend HTML/CSS/JavaScript sem build step

## Rodar localmente

### Linux/macOS — automático
Na raiz do projeto:
```bash
chmod +x rodar
./rodar
```
O script verifica Node.js 20+, instala dependências, prepara o SQLite, executa testes, verifica a sintaxe e inicia o servidor.

### Windows — automático
Dê duplo clique em `EXECUTAR-WINDOWS.bat`.

### Manual
```bash
cd backend
npm install
npm run seed
npm test
npm start
```

Abra `http://localhost:3000`.

O banco inicial fica em `backend/data/volix.sqlite`.

## Docker
```bash
docker compose up
```
O container instala as dependências, executa o seed e sobe a aplicação na porta 3000.

## Funcionalidades
- Cadastro de produto por URL canônica.
- Busca pública na Shopee e escolha do resultado.
- Coleta/recoleta manual.
- Histórico de preços sem sobrescrita.
- Separação de preço PIX e cartão quando os dados estão disponíveis.
- Atributos, imagens e variações/SKUs em tabelas próprias.
- Retry, backoff, timeout, logs e detecção de respostas de bloqueio.
- Recoleta automática a cada 6 horas por padrão.
- Dashboard responsivo com indicadores operacionais, detalhes e gráfico de histórico.
- Painel de logs de coleta e métricas das últimas 24h.
- Testes unitários do parser, anti-bot, persistência e logs.

## Variáveis de ambiente
Copie `.env.example` se desejar customizar:
```env
PORT=3000
COLLECTION_CRON=0 */6 * * *
SCRAPER_USER_AGENT=VolixCatalogMonitor/1.2 (public catalog collection)
```

## API
- `GET /api/health`
- `GET /api/products`
- `GET /api/products/:id`
- `GET /api/search?q=smartwatch`
- `POST /api/products` com `{ "url": "https://shopee.com.br/...-i.shop.item" }`
- `POST /api/products/:id/collect`

## Banco
- `product`: estado atual do produto.
- `product_attribute`: ficha técnica e atributos.
- `price_history`: cada coleta gera uma linha, preservando histórico.
- `product_image`: URLs de imagens.
- `product_variant`: variações/SKUs e preços quando disponíveis.
- `collection_log`: sucesso, bloqueio/anti-bot, erro, duração e timestamp.

## Anti-bot / Akamai
A solução não tenta burlar CAPTCHA, fingerprinting, autenticação ou controles de acesso. O scraper usa HTTP público, timeout, retries, backoff e detecção de sinais de bloqueio. Quando recebe uma página de desafio ou status 401/403/429, a coleta falha de maneira explícita e registra o evento.

Isso é intencional e documentado: para produção, uma fonte autorizada/API oficial ou outro mecanismo permitido pelo serviço deve ser priorizado.

## Os 5 produtos de referência
O banco inicial contém cinco categorias diferentes do enunciado. As URLs são páginas de produto da Shopee usadas como snapshot demonstrativo. Como marketplaces alteram estoque, preço e URLs, confirme as páginas novamente no momento da entrega e execute uma nova coleta.

## Decisões e trade-offs
O frontend não usa framework para reduzir setup e demonstrar o fluxo solicitado. O scraper é modular e testável, mas HTML/payloads de marketplace são instáveis. O scheduler local atende ao MVP; em produção, eu separaria coleta em worker/fila e adicionaria métricas/observabilidade.

## Observabilidade

O dashboard expõe contagem de produtos, coletas bem-sucedidas, bloqueios e erros nas últimas 24 horas. A API também disponibiliza `GET /api/stats` e `GET /api/logs?limit=40`. Cada coleta gera um registro de sucesso, bloqueio ou erro, sem interromper as coletas dos demais produtos.

## Limitações conhecidas
- A Shopee pode bloquear coleta automatizada.
- Estruturas HTML/payload podem mudar.
- Preços por variação dependem do payload exposto.
- Busca e coleta podem falhar durante desafios anti-bot.
- O scheduler local não substitui uma fila distribuída.

## Executar com um clique (Windows)

Se estiver usando Windows, a forma mais simples é dar duplo clique em:

```text
EXECUTAR-WINDOWS.bat
```

O script verifica o Node.js, instala as dependências, prepara o banco, executa os testes e inicia o servidor.

Também existe a versão PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\EXECUTAR-WINDOWS.ps1
```

Depois abra:

```text
http://localhost:3000
```

## Executar no Linux/macOS

O projeto inclui scripts prontos na raiz, sem necessidade de digitar os comandos do projeto manualmente.

### Linux

```bash
chmod +x rodar-linux.sh
./rodar-linux.sh
```

### macOS

```bash
chmod +x rodar-mac.sh
./rodar-mac.sh
```

### Linux/macOS — atalho universal

```bash
chmod +x rodar
./rodar
```

O fluxo completo fica em `scripts/rodar-unix.sh` e executa instalação, seed, testes, verificação de sintaxe e inicialização nessa ordem. `EXECUTAR-LINUX-MAC.sh` permanece como atalho de compatibilidade.

## Execução manual

Caso prefira executar cada etapa separadamente:

```bash
cd backend
npm install
npm run seed
npm test
npm start
```

## Recursos adicionais alinhados ao desafio
- Filtros por texto, categoria e status; ordenação por nome/preço/data e paginação.
- Comparação de 2 a 5 produtos monitorados.
- Exportação CSV dos produtos filtrados.
- Dashboard operacional com fila, sucesso/bloqueio/erro e pontos de preço.
- Fila de coleta em memória para serializar requisições e reduzir concorrência contra o marketplace.
- Cache curto de coleta configurável por `SCRAPE_CACHE_TTL_MS` (padrão: 60s), evitando chamadas duplicadas imediatas.
- Health check que valida conexão com o SQLite.

Esses recursos complementam o MVP sem alterar a proposta central de coleta, enriquecimento, persistência e operação do catálogo monitorado.

## Checklist de entrega

- [ ] `npm install` concluído sem erros
- [ ] `npm test` verde
- [ ] `npm start` abre o dashboard
- [ ] Os 5 links da Shopee foram conferidos como ativos no dia do envio
- [ ] Uma coleta real foi executada (ou o bloqueio da Shopee foi registrado e documentado)
- [ ] Histórico de preços aparece após uma nova coleta
- [ ] Exportação CSV funciona
- [ ] Docker foi testado com `docker compose up`

## Organização dos scripts de execução

Os comandos de execução já estão incluídos no projeto:

- Linux: `rodar-linux.sh`
- macOS: `rodar-mac.sh`
- Linux/macOS universal: `rodar`
- Windows: `EXECUTAR-WINDOWS.bat`
- Windows PowerShell: `EXECUTAR-WINDOWS.ps1`
- Fluxo central Unix: `scripts/rodar-unix.sh`

O fluxo automático verifica Node.js 20+, instala dependências, prepara o banco, executa os testes e só então inicia a aplicação. Consulte `COMO-RODAR.md` e `ESTRUTURA.md`.
